﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        InputSource = New TextBox()
        OutputSource = New TextBox()
        CbSource = New ComboBox()
        CbOutput = New ComboBox()
        TitleLabel = New Label()
        Label2 = New Label()
        ExitButton = New Button()
        btnConvert = New Button()
        txtAmount = New TextBox()
        lblResult = New Label()
        lblRate = New Label()
        btnClear = New Button()
        SuspendLayout()
        ' 
        ' InputSource
        ' 
        InputSource.BackColor = SystemColors.ScrollBar
        InputSource.Location = New Point(59, 102)
        InputSource.Name = "InputSource"
        InputSource.ReadOnly = True
        InputSource.Size = New Size(138, 23)
        InputSource.TabIndex = 3
        InputSource.Text = "Source Currency"
        InputSource.TextAlign = HorizontalAlignment.Center
        ' 
        ' OutputSource
        ' 
        OutputSource.BackColor = SystemColors.ScrollBar
        OutputSource.Location = New Point(247, 102)
        OutputSource.Name = "OutputSource"
        OutputSource.ReadOnly = True
        OutputSource.Size = New Size(138, 23)
        OutputSource.TabIndex = 4
        OutputSource.Text = "Output Currency"
        OutputSource.TextAlign = HorizontalAlignment.Center
        ' 
        ' CbSource
        ' 
        CbSource.DropDownStyle = ComboBoxStyle.DropDownList
        CbSource.FormattingEnabled = True
        CbSource.Location = New Point(59, 131)
        CbSource.Name = "CbSource"
        CbSource.Size = New Size(138, 23)
        CbSource.TabIndex = 5
        ' 
        ' CbOutput
        ' 
        CbOutput.DropDownStyle = ComboBoxStyle.DropDownList
        CbOutput.FormattingEnabled = True
        CbOutput.Location = New Point(247, 131)
        CbOutput.Name = "CbOutput"
        CbOutput.Size = New Size(138, 23)
        CbOutput.TabIndex = 6
        ' 
        ' TitleLabel
        ' 
        TitleLabel.AutoSize = True
        TitleLabel.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        TitleLabel.ForeColor = SystemColors.ActiveCaptionText
        TitleLabel.Location = New Point(145, 47)
        TitleLabel.Name = "TitleLabel"
        TitleLabel.Size = New Size(147, 21)
        TitleLabel.TabIndex = 8
        TitleLabel.Text = "Currency Converter"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = SystemColors.ActiveCaptionText
        Label2.Location = New Point(193, 183)
        Label2.Name = "Label2"
        Label2.Size = New Size(54, 15)
        Label2.TabIndex = 9
        Label2.Text = "Amount "
        ' 
        ' ExitButton
        ' 
        ExitButton.ForeColor = SystemColors.ActiveCaptionText
        ExitButton.Location = New Point(170, 331)
        ExitButton.Name = "ExitButton"
        ExitButton.Size = New Size(100, 51)
        ExitButton.TabIndex = 11
        ExitButton.Text = "Exit"
        ExitButton.UseVisualStyleBackColor = True
        ' 
        ' btnConvert
        ' 
        btnConvert.ForeColor = SystemColors.ActiveCaptionText
        btnConvert.Location = New Point(54, 275)
        btnConvert.Name = "btnConvert"
        btnConvert.Size = New Size(100, 39)
        btnConvert.TabIndex = 12
        btnConvert.Text = "Convert"
        btnConvert.UseVisualStyleBackColor = True
        ' 
        ' txtAmount
        ' 
        txtAmount.Location = New Point(170, 211)
        txtAmount.Name = "txtAmount"
        txtAmount.Size = New Size(100, 23)
        txtAmount.TabIndex = 7
        ' 
        ' lblResult
        ' 
        lblResult.AutoSize = True
        lblResult.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblResult.ForeColor = SystemColors.ActiveCaptionText
        lblResult.Location = New Point(160, 287)
        lblResult.Name = "lblResult"
        lblResult.Size = New Size(110, 15)
        lblResult.TabIndex = 13
        lblResult.Text = "Converted Amount"
        ' 
        ' lblRate
        ' 
        lblRate.AutoSize = True
        lblRate.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblRate.ForeColor = SystemColors.ActiveCaptionText
        lblRate.Location = New Point(170, 246)
        lblRate.Name = "lblRate"
        lblRate.Size = New Size(85, 15)
        lblRate.TabIndex = 14
        lblRate.Text = "Exchange Rate"
        ' 
        ' btnClear
        ' 
        btnClear.ForeColor = SystemColors.ActiveCaptionText
        btnClear.Location = New Point(285, 275)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(100, 39)
        btnClear.TabIndex = 15
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.CornflowerBlue
        ClientSize = New Size(435, 476)
        Controls.Add(btnClear)
        Controls.Add(lblRate)
        Controls.Add(lblResult)
        Controls.Add(btnConvert)
        Controls.Add(ExitButton)
        Controls.Add(Label2)
        Controls.Add(TitleLabel)
        Controls.Add(txtAmount)
        Controls.Add(CbOutput)
        Controls.Add(CbSource)
        Controls.Add(OutputSource)
        Controls.Add(InputSource)
        ForeColor = SystemColors.ControlLightLight
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents InputSource As TextBox
    Friend WithEvents OutputSource As TextBox
    Friend WithEvents CbSource As ComboBox
    Friend WithEvents CbOutput As ComboBox
    Friend WithEvents TitleLabel As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ExitButton As Button
    Friend WithEvents btnConvert As Button
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblResult As Label
    Friend WithEvents lblRate As Label
    Friend WithEvents btnClear As Button

End Class
