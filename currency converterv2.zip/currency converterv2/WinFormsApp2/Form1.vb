﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("Welcome to the Currency Converter")
        Dim currencies() As String = {"GBP", "USD", "EUR"}
        For Each currency In currencies
            CbSource.Items.Add(currency)
            CbOutput.Items.Add(currency)
        Next
    End Sub

    Private Sub btnConvert_Click_1(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim amount As Double
        Dim result As Double

        If txtAmount.Text = "" Then
            MessageBox.Show("Please enter an amount to convert")
            Exit Sub
        End If

        If Not Double.TryParse(txtAmount.Text, amount) Then
            MessageBox.Show("Please enter numbers only")
            Exit Sub
        End If

        If CbSource.Text = CbOutput.Text Then
            MessageBox.Show("Please do not select the same currency")
            Exit Sub
        End If

        If amount < 1 Or amount > 100000 Then
            MessageBox.Show("Please enter an amount between 1 and 100000")
            Exit Sub
        End If

        Dim conversionKey = CbSource.Text & "_" & CbOutput.Text

        Select Case conversionKey
            Case "GBP_USD"
                result = amount * 1.27
            Case "GBP_EUR"
                result = amount * 1.17
            Case "USD_GBP"
                result = amount / 1.27
            Case "USD_EUR"
                result = amount * 0.92
            Case "EUR_GBP"
                result = amount / 1.17
            Case "EUR_USD"
                result = amount / 0.92
            Case Else
                result = amount
        End Select

        lblResult.Text = result.ToString("0.00")
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        MessageBox.Show("Thank you for using the Currency Converter")
        Close()
    End Sub

    Private Sub CbOutput_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbOutput.SelectedIndexChanged
        Dim rate As Double
        Dim conversionKey As String = CbSource.Text & "_" & CbOutput.Text

        Select Case conversionKey
            Case "GBP_USD"
                rate = 1.27
            Case "GBP_EUR"
                rate = 1.17
            Case "USD_GBP"
                rate = 1 / 1.27
            Case "USD_EUR"
                rate = 0.92
            Case "EUR_GBP"
                rate = 1 / 1.17
            Case "EUR_USD"
                rate = 1 / 0.92
            Case Else
                rate = 1
        End Select

        lblRate.Text = rate.ToString("0.00")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAmount.Text = ""
        CbSource.SelectedIndex = -1
        CbOutput.SelectedIndex = -1
        lblResult.Text = ""
        lblRate.Text = ""
    End Sub

    Private Sub txtAmount_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged

    End Sub
End Class